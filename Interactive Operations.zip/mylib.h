#ifndef MYLIB_H
#define MYLIB_H

double add(double a, double b);
double multiply(double a, double b);
double divide(double a, double b);

#endif
